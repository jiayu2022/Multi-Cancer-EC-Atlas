
getwd()

library(CellChat)

library(patchwork)

library(tidyverse)

library(ggalluvial)

library(dplyr)

rm(list=ls())

options(stringsAsFactors = FALSE)

cellchat = readRDS(file = "input/lct1000ccs.rds")

CellChatDB <- CellChatDB.human

#showDatabaseCategory(CellChatDB)

# Show the structure of the database

#dplyr::glimpse(CellChatDB$interaction)

p1 = netVisual_bubble(cellchat, sources.use = 17,
                      targets.use = c(2, 3, 6:10, 12:16),
                      remove.isolate = FALSE)

p1

p = p1 + labs(title = "LC Tumor") +
         theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p

ggsave(p, file = "figure/7lcttipecs.png", width = 5, height = 4.8, dpi = 600)

ggsave(p, file = "figure/7lcttipecs.pdf", width = 5, height = 4.8)

p2 = netVisual_bubble(cellchat, sources.use = c(2, 3, 6:10, 12:16),
                      targets.use = 17,
                      remove.isolate = FALSE)

p3 = p2 + labs(title = "LC Tumor") +
          theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p3

ggsave(p3, file = "figure/8lctalltipec.png", width = 5, height = 7, dpi = 600)

ggsave(p3, file = "figure/8lctalltipec.pdf", width = 5, height = 7)

p1 = netVisual_bubble(cellchat, sources.use = 19,
                      targets.use = c(2,3,5:9,13:15,17),
                      remove.isolate = FALSE)

p1

p = p1 + labs(title = "LC Tumor") +
  theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p

ggsave(p, file = "figure/veec/7lcttipecs.png", width = 5, height = 7, dpi = 600)

ggsave(p, file = "figure/veec/7lcttipecs.pdf", width = 5, height = 7)

p2 = netVisual_bubble(cellchat, sources.use = c(2,3,5:9,13:15,17),
                      targets.use = 18,
                      remove.isolate = FALSE)

p3 = p2 + labs(title = "LC Tumor") +
  theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p3

ggsave(p3, file = "figure/8lctalltipec.png", width = 5, height = 7, dpi = 600)

ggsave(p3, file = "figure/8lctalltipec.pdf", width = 5, height = 7)

#cell-cell contact

cellchat = readRDS(file = "input/lct1000ccc.rds")

CellChatDB <- CellChatDB.human

#showDatabaseCategory(CellChatDB)

# Show the structure of the database

#dplyr::glimpse(CellChatDB$interaction)

p1 = netVisual_bubble(cellchat, sources.use = 19,
                      targets.use = c(2,3,5:9,13:15,17),
                      remove.isolate = FALSE)

p1

p = p1 + labs(title = "LC Tumor") +
  theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p

ggsave(p, file = "figure/7lcttipecs.png", width = 5, height = 4.5, dpi = 600)

ggsave(p, file = "figure/7lcttipecs.pdf", width = 5, height = 4.5)

p2 = netVisual_bubble(cellchat, sources.use = c(2,3,5:9,13:15,17),
                      targets.use = 18,
                      remove.isolate = FALSE)

p3 = p2 + labs(title = "LC Tumor") +
  theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p3

ggsave(p3, file = "figure/8lctalltipec.png", width = 5, height = 7, dpi = 600)

ggsave(p3, file = "figure/8lctalltipec.pdf", width = 5, height = 7)

p1 = netVisual_bubble(cellchat, sources.use = 19,
                      targets.use = c(2,3,5:9,13:15,17),
                      remove.isolate = FALSE)

p1

p = p1 + labs(title = "LC Tumor") +
  theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p

ggsave(p, file = "figure/veec/7lcttipecs.png", width = 5, height = 7, dpi = 600)

ggsave(p, file = "figure/veec/7lcttipecs.pdf", width = 5, height = 7)

p2 = netVisual_bubble(cellchat, sources.use = c(2,3,5:9,13:15,17),
                      targets.use = 18,
                      remove.isolate = FALSE)

p3 = p2 + labs(title = "LC Tumor") +
  theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p3

ggsave(p3, file = "figure/8lctalltipec.png", width = 5, height = 7, dpi = 600)

ggsave(p3, file = "figure/8lctalltipec.pdf", width = 5, height = 7)

