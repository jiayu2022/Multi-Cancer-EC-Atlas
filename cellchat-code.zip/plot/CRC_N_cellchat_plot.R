
getwd()

library(CellChat)

library(patchwork)

library(tidyverse)

library(ggalluvial)

library(dplyr)

rm(list=ls())

options(stringsAsFactors = FALSE)

dir.create("figure")

cellchat = readRDS(file = "input/crcn1000ccs.rds")

CellChatDB <- CellChatDB.human

#showDatabaseCategory(CellChatDB)

# Show the structure of the database

#dplyr::glimpse(CellChatDB$interaction)

p1 = netVisual_bubble(cellchat, sources.use = 16,
                      targets.use = c(1:18),
                      remove.isolate = FALSE)

p1

p1 = netVisual_bubble(cellchat, sources.use = 17,
                      targets.use = c(2, 3, 6:10, 12:16),
                      remove.isolate = FALSE)

p1

p = p1 + labs(title = "CRC Normal") +
         theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p

ggsave(p, file = "figure/1crcntipecs.png", width = 5, height = 5, dpi = 600)

ggsave(p, file = "figure/1crcntipecs.pdf", width = 5, height = 5)

p2 = netVisual_bubble(cellchat, sources.use = c(2, 3, 6:10, 12:16),
                      targets.use = 17,
                      remove.isolate = FALSE)

p3 = p2 + labs(title = "CRC Normal") +
          theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p3

ggsave(p3, file = "figure/2crcnalltipec.png", width = 5, height = 7.5, dpi = 600)

ggsave(p3, file = "figure/2crcnalltipec.pdf", width = 5, height = 7.5)

#vec

p1 = netVisual_bubble(cellchat, sources.use = 16,
                      targets.use = c(1:20),
                      remove.isolate = FALSE)

p1

p1 = netVisual_bubble(cellchat, sources.use = 17,
                      targets.use = c(2, 3, 5:9, 11:13, 15),
                      remove.isolate = FALSE)

p1

p = p1 + labs(title = "CRC Normal") +
  theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p

ggsave(p, file = "figure/veec/1crcnveecs.png", width = 5, height = 4.8, dpi = 600)

ggsave(p, file = "figure/veec/1crcnveecs.pdf", width = 5, height = 4.8)

p2 = netVisual_bubble(cellchat, sources.use = c(2, 3, 5:9, 11:13, 15),
                      targets.use = 17,
                      remove.isolate = FALSE)

p3 = p2 + labs(title = "CRC Normal") +
  theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p3

ggsave(p3, file = "figure/veec/2crcnallveec.png", width = 5, height = 7.5, dpi = 600)

ggsave(p3, file = "figure/veec/2crcnallveec.pdf", width = 5, height = 7.5)


