
getwd()

library(CellChat)

library(patchwork)

library(tidyverse)

library(ggalluvial)

library(dplyr)

rm(list=ls())

options(stringsAsFactors = FALSE)

cellchat = readRDS(file = "input/crct1000ccs.rds")

CellChatDB <- CellChatDB.human

#showDatabaseCategory(CellChatDB)

# Show the structure of the database

#dplyr::glimpse(CellChatDB$interaction)

p1 = netVisual_bubble(cellchat, sources.use = 17,
                      targets.use = c(2, 3, 6:10, 12:16),
                      remove.isolate = FALSE)

p1

p = p1 + labs(title = "CRC Tumor") +
         theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p

ggsave(p, file = "figure/3crcttipecs.png", width = 5, height = 7.5, dpi = 600)

ggsave(p, file = "figure/3crcttipecs.pdf", width = 5, height = 7.5)

p2 = netVisual_bubble(cellchat, sources.use = c(2, 3, 6:10, 12:16),
                      targets.use = 17,
                      remove.isolate = FALSE)

p3 = p2 + labs(title = "CRC Tumor") +
          theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p3

ggsave(p3, file = "figure/4crctalltipec.png", width = 5, height = 8, dpi = 600)

ggsave(p3, file = "figure/4crctalltipec.pdf", width = 5, height = 8)

p1 = netVisual_bubble(cellchat, sources.use = 18,
                      targets.use = c(2, 3, 5:9, 12:14, 16),
                      remove.isolate = FALSE)

p1

p = p1 + labs(title = "CRC Tumor") +
  theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p

ggsave(p, file = "figure/veec/3crctveecs.png", width = 5, height = 7.5, dpi = 600)

ggsave(p, file = "figure/veec/3crctveecs.pdf", width = 5, height = 7.5)

p2 = netVisual_bubble(cellchat, sources.use = c(2, 3, 5:9, 12:14, 16),
                      targets.use = 18,
                      remove.isolate = FALSE)

p3 = p2 + labs(title = "CRC Tumor") +
  theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p3

ggsave(p3, file = "figure/veec/4crctallveec.png", width = 5, height = 8, dpi = 600)

ggsave(p3, file = "figure/veec/4crctallveec.pdf", width = 5, height = 8)


