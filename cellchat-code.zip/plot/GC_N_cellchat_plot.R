
getwd()

library(CellChat)

library(patchwork)

library(tidyverse)

library(ggalluvial)

library(dplyr)

rm(list=ls())

options(stringsAsFactors = FALSE)

cellchat = readRDS(file = "input/gcn1000ccs.rds")

CellChatDB <- CellChatDB.human

#showDatabaseCategory(CellChatDB)

# Show the structure of the database

#dplyr::glimpse(CellChatDB$interaction)

p1 = netVisual_bubble(cellchat, sources.use = 6, targets.use = c(1:18),
                      remove.isolate = FALSE)

p1

p = p1 + labs(title = "GC Normal") +
         theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p

ggsave(p, file = "figure/gcnecs.png", width = 5, height = 3, dpi = 600)

ggsave(p, file = "figure/gcnecs.pdf", width = 5, height = 3)

p2 = netVisual_bubble(cellchat, sources.use = c(1:12), targets.use = 6,
                      remove.isolate = FALSE)

p3 = p2 + labs(title = "GC Normal") +
          theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p3

ggsave(p3, file = "figure/gcnallec.png", width = 5, height = 4, dpi = 600)

ggsave(p3, file = "figure/gcnallec.pdf", width = 5, height = 4)

p1 = netVisual_bubble(cellchat, sources.use = 6, targets.use = c(1:18),
                      remove.isolate = FALSE)

p1

p = p1 + labs(title = "GC Normal") +
  theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p

ggsave(p, file = "figure/gcnecs.png", width = 5, height = 3, dpi = 600)

ggsave(p, file = "figure/gcnecs.pdf", width = 5, height = 3)

p2 = netVisual_bubble(cellchat, sources.use = c(1:12), targets.use = 6,
                      remove.isolate = FALSE)

p3 = p2 + labs(title = "GC Normal") +
  theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p3

ggsave(p3, file = "figure/gcnallec.png", width = 5, height = 4, dpi = 600)

ggsave(p3, file = "figure/gcnallec.pdf", width = 5, height = 4)


