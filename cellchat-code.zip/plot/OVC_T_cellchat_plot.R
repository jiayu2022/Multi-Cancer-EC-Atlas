
getwd()

library(CellChat)

library(patchwork)

library(tidyverse)

library(ggalluvial)

library(dplyr)

rm(list=ls())

options(stringsAsFactors = FALSE)

cellchat = readRDS(file = "input/ovct1000ccs.rds")

CellChatDB <- CellChatDB.human

#showDatabaseCategory(CellChatDB)

# Show the structure of the database

#dplyr::glimpse(CellChatDB$interaction)

p1 = netVisual_bubble(cellchat, sources.use = 17,
                      targets.use = c(2, 3, 6:10, 12:16),
                      remove.isolate = FALSE)

p1

p = p1 + labs(title = "OVC Tumor") +
         theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p

ggsave(p, file = "figure/9ovcttipecs.png", width = 5, height = 7,
          dpi = 600)

ggsave(p, file = "figure/9ovcttipecs.pdf", width = 5, height = 7)

p2 = netVisual_bubble(cellchat, sources.use = c(2, 3, 6:10, 12:16),
                      targets.use = 17,
                      remove.isolate = FALSE)

p3 = p2 + labs(title = "OVC Tumor") +
          theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p3

ggsave(p3, file = "figure/10ovctalltipec.png", width = 5, height = 5.8,
           dpi = 600)

ggsave(p3, file = "figure/10ovctalltipec.pdf", width = 5, height = 5.8)



