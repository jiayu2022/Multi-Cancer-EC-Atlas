
getwd()

library(CellChat)

library(patchwork)

library(tidyverse)

library(ggalluvial)

library(dplyr)

rm(list=ls())

options(stringsAsFactors = FALSE)

cellchat = readRDS(file = "input/lcn1000ccs.rds")

CellChatDB <- CellChatDB.human

#showDatabaseCategory(CellChatDB)

# Show the structure of the database

#dplyr::glimpse(CellChatDB$interaction)

p1 = netVisual_bubble(cellchat, sources.use = 17,
                      targets.use = c(2, 3, 6:10, 12:16),
                      remove.isolate = FALSE)

p1

p = p1 + labs(title = "LC Normal") +
         theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p

ggsave(p, file = "figure/lcnecs.png", width = 5, height = 3.9, dpi = 600)

ggsave(p, file = "figure/lcnecs.pdf", width = 5, height = 3.9)

p2 = netVisual_bubble(cellchat, sources.use = c(2, 3, 6:10, 12:16),
                      targets.use = 17,
                      remove.isolate = FALSE)

p3 = p2 + labs(title = "LC Normal") +
          theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p3

ggsave(p3, file = "figure/lcnallec.png", width = 5, height = 4, dpi = 600)

ggsave(p3, file = "figure/lcnallec.pdf", width = 5, height = 4)

p1 = netVisual_bubble(cellchat, sources.use = 19,
                      targets.use = c(2, 3, 5:9, 13:15, 17),
                      remove.isolate = FALSE)

p1

p = p1 + labs(title = "LC Normal") +
  theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p

ggsave(p, file = "figure/veec/lcnveecs.png", width = 5, height = 3.9, dpi = 600)

ggsave(p, file = "figure/veec/lcnveecs.pdf", width = 5, height = 3.9)

p2 = netVisual_bubble(cellchat, sources.use = c(2, 3, 5:9, 13:15, 17),
                      targets.use = 19,
                      remove.isolate = FALSE)

p3 = p2 + labs(title = "LC Normal") +
  theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p3

ggsave(p3, file = "figure/veec/lcnallveec.png", width = 5, height = 5.5, dpi = 600)

ggsave(p3, file = "figure/veec/lcnallveec.pdf", width = 5, height = 5.5)


