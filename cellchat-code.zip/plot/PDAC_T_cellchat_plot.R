
getwd()

library(CellChat)

library(patchwork)

library(tidyverse)

library(ggalluvial)

library(dplyr)

rm(list=ls())

options(stringsAsFactors = FALSE)

cellchat = readRDS(file = "input/pdact1000ccs.rds")

CellChatDB <- CellChatDB.human

#showDatabaseCategory(CellChatDB)

# Show the structure of the database

#dplyr::glimpse(CellChatDB$interaction)

p1 = netVisual_bubble(cellchat, sources.use = 17,
                      targets.use = c(2, 3, 6:10, 12:16),
                      remove.isolate = FALSE)

p1

p = p1 + labs(title = "PDAC Tumor") +
         theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p

ggsave(p, file = "figure/11pdactecs.png", width = 5, height = 10.8, dpi = 600)

ggsave(p, file = "figure/11pdactecs.pdf", width = 5, height = 10.8)

p2 = netVisual_bubble(cellchat, sources.use = c(2, 3, 6:10, 12:16),
                      targets.use = 17,
                      remove.isolate = FALSE)

p3 = p2 + labs(title = "PDAC Tumor") +
          theme(plot.title = element_text(hjust = 0.5, size = 10.5))

p3

ggsave(p3, file = "figure/12pdactallec.png", width = 5, height = 12.5, dpi = 600)

ggsave(p3, file = "figure/12pdactallec.pdf", width = 5, height = 12.5)



