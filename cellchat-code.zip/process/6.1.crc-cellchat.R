
setwd("/home/zhangjiayu/project/EC/process/7.tipeccellchat")

getwd()

library(Seurat)

library(CellChat)

library(tidyverse)

library(patchwork)

library(dplyr)

library(ggalluvial)

library(future)

rm(list = ls())

options(stringsAsFactors = FALSE)

plan()

dir.create("process")

dir.create("out")

###CRC-T

crct = readRDS(file = "input/crctsub.rds")

table(crct$subtype)

Idents(crct) = crct$subtype

table(Idents(crct))

crctsub = subset(crct, downsample = 1000)

table(crctsub$subtype)

saveRDS(crctsub, file = "process/crct1000.rds")

crctsub = readRDS(file = "process/crct1000.rds")

scRNA = crctsub

# CellChat要求输入标准化后的表达数据

data.input <- GetAssayData(scRNA, assay = "RNA", slot = "data")

identity <- subset(scRNA@meta.data, select = "subtype")

##创建cellchat对象

cellchat <- createCellChat(object = scRNA, group.by = "subtype")

cellchat <- addMeta(cellchat, meta = identity, meta.name = "labels")

cellchat <- setIdent(cellchat, ident.use = "labels")

groupSize <- as.numeric(table(cellchat@idents)) # 后面有用

##设置参考数据库

# 选择合适的物种，可选CellChatDB.human, CellChatDB.mouse

CellChatDB <- CellChatDB.human

# 使用所有配体受体作用用于细胞通讯分析

CellChatDB.use <- subsetDB(CellChatDB, search = "Secreted Signaling")

# 将数据库传递给cellchat对象

cellchat@DB <- CellChatDB.use

##配体-受体分析

# 提取数据库支持的数据子集

cellchat <- subsetData(cellchat)

future::plan("multicore", workers = 56)

plan()

# 识别过表达基因

cellchat <- identifyOverExpressedGenes(cellchat)

# 识别配体-受体对

cellchat <- identifyOverExpressedInteractions(cellchat)

# 将配体、受体投射到PPI网络

cellchat <- projectData(cellchat, PPI.mouse)

##推测细胞通讯网络

cellchat <- computeCommunProb(cellchat, raw.use = TRUE)

# Filter out the cell-cell communication if there are only few number of cells in certain cell groups

cellchat <- filterCommunication(cellchat, min.cells = 20)

cellchat <- computeCommunProbPathway(cellchat)

cellchat <- aggregateNet(cellchat)

saveRDS(cellchat, file = "out/crct1000ccs.rds")

###CRC-N

rm(list = ls())

scRNA = readRDS(file = "input/crcnsub.rds")

table(scRNA$celltype)

table(Idents(scRNA))

scRNAsub = subset(scRNA, downsample = 1000)

table(scRNAsub$celltype)

saveRDS(scRNAsub, file = "process/crcn1000.rds")

scRNAsub = readRDS(file = "process/crcn1000.rds")

scRNA = scRNAsub

# CellChat要求输入标准化后的表达数据

data.input <- GetAssayData(scRNA, assay = "RNA", slot = "data")

identity <- subset(scRNA@meta.data, select = "subtype")

##创建cellchat对象

cellchat <- createCellChat(object = scRNA,group.by = "subtype")

cellchat <- addMeta(cellchat, meta = identity, meta.name = "labels")

cellchat <- setIdent(cellchat, ident.use = "labels")

groupSize <- as.numeric(table(cellchat@idents)) # 后面有用

##设置参考数据库

# 选择合适的物种，可选CellChatDB.human, CellChatDB.mouse

CellChatDB <- CellChatDB.human

# use a subset of CellChatDB for cell-cell communication analysis

CellChatDB.use <- subsetDB(CellChatDB, search = "Secreted Signaling") # use Secreted Signaling

# 将数据库传递给cellchat对象

cellchat@DB <- CellChatDB.use

##配体-受体分析

# 提取数据库支持的数据子集

cellchat <- subsetData(cellchat)

future::plan("multicore", workers = 56)

plan()

# 识别过表达基因

cellchat <- identifyOverExpressedGenes(cellchat)

# 识别配体-受体对

cellchat <- identifyOverExpressedInteractions(cellchat)

# 将配体、受体投射到PPI网络

cellchat <- projectData(cellchat, PPI.mouse)

##推测细胞通讯网络

cellchat <- computeCommunProb(cellchat, raw.use = TRUE)

# Filter out the cell-cell communication if there are only few number of cells in certain cell groups

cellchat <- filterCommunication(cellchat, min.cells = 20)

cellchat <- computeCommunProbPathway(cellchat)

cellchat <- aggregateNet(cellchat)

saveRDS(cellchat, file = "out/crcn1000ccs.rds")

